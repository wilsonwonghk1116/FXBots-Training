import os

# CONFIGURATION
# General training parameters
GENERATIONS = 200
CHECKPOINT_INTERVAL = 10

# Population settings
# Total population will be sum of these
POP_SIZE_3090 = 1000 
POP_SIZE_3070 = 250

# Resource allocation for each node
GPU_3090 = 1
GPU_3070 = 1
CPU_3090 = 76
CPU_3070 = 14

# NEW: CPU Safety Governor
# This prevents us from using 100% of the assigned CPUs for simulation actors,
# reserving a buffer for the Raylet and OS to prevent heartbeat failures.
# 0.8 means we will use 80% of the allocated CPU cores for actors.
ACTOR_CPU_SCALE_FACTOR = 0.8

# Data paths
EURUSD_H1_PATH = os.path.join(os.path.dirname(__file__), 'data', 'EURUSD_H1.csv')

# File paths
CHECKPOINT_DIR = 'checkpoints/'
MODEL_DIR = 'models/' 