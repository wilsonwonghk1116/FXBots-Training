# Automated Cluster Training Configuration
# ======================================

# Network Configuration
PC1_IP = "192.168.0.238"
PC2_IP = "192.168.0.145"
PC2_USER = "w1"

# SSH Configuration (Update with your actual password)
PC2_SSH_PASSWORD = "w"

# Ray Configuration
RAY_PORT = 10001
RAY_DASHBOARD_PORT = 8265

# Hardware Configuration (75% utilization for optimal performance)
PC1_TOTAL_CPUS = 80
PC1_TOTAL_GPUS = 1
PC1_TOTAL_VRAM_GB = 24  # RTX 3090

PC2_TOTAL_CPUS = 16
PC2_TOTAL_GPUS = 1
PC2_TOTAL_VRAM_GB = 8   # RTX 3070

# 50% Utilization Settings
UTILIZATION_PERCENTAGE = 0.50

# Calculated 50% Resource Allocation
PC1_CPUS = int(PC1_TOTAL_CPUS * UTILIZATION_PERCENTAGE)     # 40 CPUs (50% of 80)
PC1_GPUS = PC1_TOTAL_GPUS  # Use full GPU but limit VRAM to 50%
PC1_OBJECT_STORE_MEMORY = int(PC1_TOTAL_VRAM_GB * UTILIZATION_PERCENTAGE * 1024**3)  # 12GB (50% of 24GB)

PC2_CPUS = int(PC2_TOTAL_CPUS * UTILIZATION_PERCENTAGE)     # 8 CPUs (50% of 16)
PC2_GPUS = PC2_TOTAL_GPUS  # Use full GPU but limit VRAM to 50%
PC2_OBJECT_STORE_MEMORY = int(PC2_TOTAL_VRAM_GB * UTILIZATION_PERCENTAGE * 1024**3)  # 4GB (50% of 8GB)

# Ray Actor Resource Configuration (75% utilization)
RAY_TRAINER_CPUS = 8        # 75% of available cores per trainer
RAY_TRAINER_GPU_FRACTION = 0.75  # 75% GPU utilization per trainer
RAY_COORDINATOR_CPUS = 3    # Coordinator uses minimal resources

# Worker Configuration (optimized for 75% utilization)
WORKERS_PER_PC = 2          # Reduced from 3 to maintain 75% utilization
MAX_CONCURRENT_TRAINERS = 4 # Total trainers across both PCs

# GPU Memory Management (50% VRAM usage)
PC1_GPU_MEMORY_FRACTION = 0.50  # Use 50% of RTX 3090 VRAM
PC2_GPU_MEMORY_FRACTION = 0.50  # Use 50% of RTX 3070 VRAM

# Training Optimization for 50% utilization
BATCH_SIZE_REDUCTION = 0.50     # Reduce batch sizes by 50%
PARALLEL_EPISODES_REDUCTION = 0.50  # Reduce parallel episodes by 50%

# Python Environment
CONDA_ENV_NAME = "Training_env"

# Training Configuration
TEST_GENERATIONS = 2
TEST_EPISODES = 10
TEST_STEPS = 100

FULL_GENERATIONS = 200
FULL_EPISODES = 1000
FULL_STEPS = 1000
